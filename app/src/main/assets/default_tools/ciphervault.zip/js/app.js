/**
 * Author: Faysal Alibrahim
 * GitHub: https://github.com/FAYSAL-Q8
 */
const Native = {
  toast: (msg) => {
    if (window.AndroidBridge?.showToast) window.AndroidBridge.showToast(msg);
    else console.log("[Toast]", msg);
  },
  copy: async (text) => {
    if (window.AndroidBridge?.copyToClipboard) {
      window.AndroidBridge.copyToClipboard(text);
    } else {
      await navigator.clipboard.writeText(text);
    }
    Native.toast("Copied to clipboard!");
  },
  vibrate: (ms = 50) => {
    if (window.AndroidBridge?.vibrate) window.AndroidBridge.vibrate(ms);
    else if (navigator.vibrate) navigator.vibrate(ms);
  },
  share: (title, text) => {
    if (window.AndroidBridge?.shareText) window.AndroidBridge.shareText(title, text);
    else if (navigator.share) navigator.share({ title, text });
    else Native.copy(text);
  },
  saveData: (key, value) => {
    if (window.AndroidBridge?.saveData) window.AndroidBridge.saveData(key, value);
    else localStorage.setItem(key, value);
  },
  getData: (key) => {
    if (window.AndroidBridge?.getData) return window.AndroidBridge.getData(key);
    return localStorage.getItem(key);
  }
};

// Theme Management
function initTheme() {
  const saved = Native.getData('app_theme') || localStorage.getItem('app_theme') || 'light';
  applyTheme(saved);

  window.addEventListener('message', (e) => {
    if (e.data && e.data.type === 'SET_THEME') {
      applyTheme(e.data.theme);
    }
  });

  window.addEventListener('storage', (e) => {
    if (e.key === 'app_theme' && e.newValue) {
      applyTheme(e.newValue);
    }
  });
}

function applyTheme(theme) {
  document.documentElement.setAttribute('data-theme', theme);
  document.body.classList.toggle('dark', theme === 'dark');
  Native.saveData('app_theme', theme);
  localStorage.setItem('app_theme', theme);
  updateThemeIcon(theme);
}

function toggleTheme() {
  const current = document.documentElement.getAttribute('data-theme') === 'dark' ? 'dark' : 'light';
  const next = current === 'dark' ? 'light' : 'dark';
  applyTheme(next);
  Native.vibrate(30);
  Native.toast(`Switched to ${next} mode`);
}

function updateThemeIcon(theme) {
  const icon = document.getElementById('themeIcon');
  if (!icon) return;
  if (theme === 'dark') {
    icon.innerHTML = `<svg fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 3v1m0 16v1m9-9h-1M4 12H3m15.364 6.364l-.707-.707M6.343 6.343l-.707-.707m12.728 0l-.707.707M6.343 17.657l-.707.707M16 12a4 4 0 11-8 0 4 4 0 018 0z"/></svg>`;
  } else {
    icon.innerHTML = `<svg fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M20.354 15.354A9 9 0 018.646 3.646 9.003 9.003 0 0012 21a9.003 9.003 0 008.354-5.646z"/></svg>`;
  }
}

// Application State
let activeOp = 'encrypt';
let activeTarget = 'file';
let selectedFile = null;
let currentResultText = '';
let currentDownloadBlob = null;
let currentDownloadFilename = '';

document.addEventListener('DOMContentLoaded', () => {
  initTheme();
  initDropzone();
});

function initDropzone() {
  const dropzone = document.getElementById('dropzone');
  const fileInput = document.getElementById('fileInput');

  dropzone.addEventListener('click', () => fileInput.click());
  fileInput.addEventListener('change', (e) => handleFileSelected(e.target.files[0]));

  dropzone.addEventListener('dragover', (e) => {
    e.preventDefault();
    dropzone.classList.add('dragover');
  });
  dropzone.addEventListener('dragleave', () => dropzone.classList.remove('dragover'));
  dropzone.addEventListener('drop', (e) => {
    e.preventDefault();
    dropzone.classList.remove('dragover');
    if (e.dataTransfer.files.length) handleFileSelected(e.dataTransfer.files[0]);
  });
}

function handleFileSelected(file) {
  if (!file) return;
  selectedFile = file;
  document.getElementById('fileName').textContent = file.name;
  document.getElementById('fileMeta').textContent = `${(file.size / (1024 * 1024)).toFixed(2)} MB • ${file.type || 'Binary'}`;
  document.getElementById('filePlaceholder').style.display = 'none';
  document.getElementById('fileActiveBox').style.display = 'block';
  hideResult();
  Native.vibrate(30);
}

function clearSelectedFile(e) {
  if (e) e.stopPropagation();
  selectedFile = null;
  document.getElementById('fileInput').value = '';
  document.getElementById('filePlaceholder').style.display = 'block';
  document.getElementById('fileActiveBox').style.display = 'none';
  hideResult();
}

function switchOp(op) {
  activeOp = op;
  document.querySelectorAll('.segment-btn').forEach(btn => {
    btn.classList.toggle('active', btn.dataset.op === op);
  });

  const passGroup = document.getElementById('passphraseGroup');
  const hashGroup = document.getElementById('hashAlgoGroup');

  if (op === 'hash') {
    passGroup.style.display = 'none';
    hashGroup.style.display = 'flex';
  } else {
    passGroup.style.display = 'flex';
    hashGroup.style.display = 'none';
  }

  updateActionLabels();
  hideResult();
  Native.vibrate(25);
}

function switchTarget(target) {
  activeTarget = target;
  document.getElementById('targetFileBtn').classList.toggle('active', target === 'file');
  document.getElementById('targetTextBtn').classList.toggle('active', target === 'text');

  document.getElementById('fileSection').style.display = target === 'file' ? 'block' : 'none';
  document.getElementById('textSection').style.display = target === 'text' ? 'block' : 'none';

  updateActionLabels();
  hideResult();
  Native.vibrate(25);
}

function updateActionLabels() {
  const btnText = document.getElementById('actionBtnText');
  const textLabel = document.getElementById('textInputLabel');

  const opLabel = activeOp === 'encrypt' ? 'Encrypt' : (activeOp === 'decrypt' ? 'Decrypt' : 'Hash');
  const targetLabel = activeTarget === 'file' ? 'File' : 'Text';
  btnText.textContent = `${opLabel} ${targetLabel}`;

  if (activeOp === 'decrypt') {
    textLabel.textContent = 'Ciphertext (Base64)';
  } else if (activeOp === 'hash') {
    textLabel.textContent = 'Text to Hash';
  } else {
    textLabel.textContent = 'Text to Encrypt';
  }
}

function togglePasswordVisibility() {
  const input = document.getElementById('passphrase');
  input.type = input.type === 'password' ? 'text' : 'password';
}

function hideResult() {
  document.getElementById('resultCard').style.display = 'none';
  currentResultText = '';
  currentDownloadBlob = null;
}

// Main Execution
async function executeCrypto() {
  const pass = document.getElementById('passphrase').value;
  if (activeOp !== 'hash' && !pass) {
    Native.toast("Enter a passphrase");
    return;
  }

  setLoading(true);
  hideResult();

  try {
    let inputBuffer;
    if (activeTarget === 'file') {
      if (!selectedFile) throw new Error("Select a file first");
      inputBuffer = await selectedFile.arrayBuffer();
    } else {
      const rawText = document.getElementById('rawTextInput').value;
      if (!rawText.trim()) throw new Error("Enter text to process");

      if (activeOp === 'decrypt') {
        inputBuffer = base64ToArrayBuffer(rawText.trim());
      } else {
        inputBuffer = new TextEncoder().encode(rawText).buffer;
      }
    }

    if (activeOp === 'hash') {
      const algo = document.getElementById('hashAlgo').value;
      const hashBuffer = await crypto.subtle.digest(algo, inputBuffer);
      const hashHex = Array.from(new Uint8Array(hashBuffer))
        .map(b => b.toString(16).padStart(2, '0'))
        .join('');

      showTextResult(hashHex, `${algo} Hash`, `${algo.toLowerCase()}_hash.txt`);
    } else if (activeOp === 'encrypt') {
      await runEncryption(inputBuffer, pass);
    } else if (activeOp === 'decrypt') {
      await runDecryption(inputBuffer, pass);
    }

    Native.vibrate(50);
  } catch (err) {
    showError(err.message || "Crypto operation failed");
    Native.vibrate(100);
  } finally {
    setLoading(false);
  }
}

// AES-256-GCM Encryption
async function runEncryption(dataBuffer, password) {
  const salt = crypto.getRandomValues(new Uint8Array(16));
  const iv = crypto.getRandomValues(new Uint8Array(12));

  const key = await deriveKey(password, salt);
  const ciphertext = await crypto.subtle.encrypt({ name: "AES-GCM", iv: iv }, key, dataBuffer);

  const payload = new Uint8Array(salt.byteLength + iv.byteLength + ciphertext.byteLength);
  payload.set(salt, 0);
  payload.set(iv, salt.byteLength);
  payload.set(new Uint8Array(ciphertext), salt.byteLength + iv.byteLength);

  if (activeTarget === 'file') {
    const blob = new Blob([payload], { type: "application/octet-stream" });
    showBinaryResult(blob, `${selectedFile.name}.enc`, "File encrypted (AES-256-GCM)");
  } else {
    const base64Cipher = arrayBufferToBase64(payload);
    showTextResult(base64Cipher, "Encrypted (Base64)", "encrypted.txt");
  }
}

// AES-256-GCM Decryption
async function runDecryption(dataBuffer, password) {
  if (dataBuffer.byteLength < 28) {
    throw new Error("Invalid payload: shorter than 28-byte header");
  }

  const salt = new Uint8Array(dataBuffer.slice(0, 16));
  const iv = new Uint8Array(dataBuffer.slice(16, 28));
  const ciphertext = dataBuffer.slice(28);

  const key = await deriveKey(password, salt);
  const decrypted = await crypto.subtle.decrypt({ name: "AES-GCM", iv: iv }, key, ciphertext);

  if (activeTarget === 'file') {
    const blob = new Blob([decrypted]);
    const outName = selectedFile.name.endsWith('.enc') ? selectedFile.name.slice(0, -4) : `decrypted_${selectedFile.name}`;
    showBinaryResult(blob, outName, "File decrypted successfully");
  } else {
    const plainText = new TextDecoder().decode(decrypted);
    showTextResult(plainText, "Decrypted Plaintext", "decrypted.txt");
  }
}

// PBKDF2 Key Derivation
async function deriveKey(password, salt) {
  const rawKey = await crypto.subtle.importKey("raw", new TextEncoder().encode(password), "PBKDF2", false, ["deriveKey"]);
  return crypto.subtle.deriveKey(
    { name: "PBKDF2", salt: salt, iterations: 100000, hash: "SHA-256" },
    rawKey,
    { name: "AES-GCM", length: 256 },
    false,
    ["encrypt", "decrypt"]
  );
}

// Result Presentations
function showTextResult(content, title, filename) {
  currentResultText = content;
  currentDownloadBlob = new Blob([content], { type: 'text/plain;charset=utf-8' });
  currentDownloadFilename = filename;

  const card = document.getElementById('resultCard');
  document.getElementById('resultTitle').textContent = title;
  const contentEl = document.getElementById('resultContent');
  contentEl.textContent = content;
  contentEl.style.display = 'block';

  document.getElementById('resultMeta').textContent = `${content.length} characters`;
  document.getElementById('copyBtn').style.display = 'inline-flex';
  document.getElementById('shareBtn').style.display = 'inline-flex';
  card.style.display = 'flex';
  Native.toast("Operation completed");
}

function showBinaryResult(blob, filename, message) {
  currentResultText = '';
  currentDownloadBlob = blob;
  currentDownloadFilename = filename;

  const card = document.getElementById('resultCard');
  document.getElementById('resultTitle').textContent = "File Ready";
  const contentEl = document.getElementById('resultContent');
  contentEl.style.display = 'none';

  document.getElementById('resultMeta').textContent = `${message} • ${(blob.size / 1024).toFixed(1)} KB`;
  document.getElementById('copyBtn').style.display = 'none';
  document.getElementById('shareBtn').style.display = 'none';
  card.style.display = 'flex';
  Native.toast(message);
}

function showError(msg) {
  const card = document.getElementById('resultCard');
  document.getElementById('resultTitle').textContent = "Error";
  const contentEl = document.getElementById('resultContent');
  contentEl.textContent = msg;
  contentEl.style.display = 'block';
  document.getElementById('resultMeta').textContent = "Check passphrase or format";
  document.getElementById('copyBtn').style.display = 'none';
  document.getElementById('shareBtn').style.display = 'none';
  card.style.display = 'flex';
  Native.toast(msg);
}

function copyResult() {
  if (currentResultText) {
    Native.copy(currentResultText);
  }
}

function shareResult() {
  if (currentResultText) {
    Native.share("CipherVault Output", currentResultText);
  }
}

function downloadResult() {
  if (!currentDownloadBlob) return;
  const link = document.createElement('a');
  link.href = URL.createObjectURL(currentDownloadBlob);
  link.download = currentDownloadFilename;
  document.body.appendChild(link);
  link.click();
  document.body.removeChild(link);
  Native.toast("Download started");
  Native.vibrate(30);
}

function setLoading(isLoading) {
  const btn = document.getElementById('actionBtn');
  const spinner = document.getElementById('btnSpinner');
  btn.disabled = isLoading;
  spinner.style.display = isLoading ? 'inline-block' : 'none';
}

// Helpers
function arrayBufferToBase64(buffer) {
  let binary = '';
  const bytes = new Uint8Array(buffer);
  for (let i = 0; i < bytes.byteLength; i++) {
    binary += String.fromCharCode(bytes[i]);
  }
  return btoa(binary);
}

function base64ToArrayBuffer(base64) {
  const binaryString = atob(base64);
  const bytes = new Uint8Array(binaryString.length);
  for (let i = 0; i < binaryString.length; i++) {
    bytes[i] = binaryString.charCodeAt(i);
  }
  return bytes.buffer;
}
