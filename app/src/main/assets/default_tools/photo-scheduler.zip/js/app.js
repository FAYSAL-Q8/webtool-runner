/**
 * Author: Faysal Alibrahim
 * GitHub: https://github.com/FAYSAL-Q8
 */
const Native = {
  toast: (msg) => {
    if (window.AndroidBridge?.showToast) window.AndroidBridge.showToast(msg);
    else console.log("[Toast]", msg);
  },
  copy: async (text) => {
    if (window.AndroidBridge?.copyToClipboard) {
      window.AndroidBridge.copyToClipboard(text);
    } else {
      await navigator.clipboard.writeText(text);
    }
    Native.toast("Copied to clipboard!");
  },
  vibrate: (ms = 50) => {
    if (window.AndroidBridge?.vibrate) window.AndroidBridge.vibrate(ms);
    else if (navigator.vibrate) navigator.vibrate(ms);
  },
  share: (title, text) => {
    if (window.AndroidBridge?.shareText) window.AndroidBridge.shareText(title, text);
    else if (navigator.share) navigator.share({ title, text });
  },
  saveData: (key, value) => {
    if (window.AndroidBridge?.saveData) window.AndroidBridge.saveData(key, value);
    else localStorage.setItem(key, value);
  },
  getData: (key) => {
    if (window.AndroidBridge?.getData) return window.AndroidBridge.getData(key);
    return localStorage.getItem(key);
  },
  addToCalendar: (task) => {
    const start = new Date(task.deadline).getTime();
    const end = start + (60 * 60 * 1000);

    if (window.AndroidBridge?.addToCalendar) {
      window.AndroidBridge.addToCalendar(task.title, task.description || "", start, end);
      Native.vibrate(40);
      Native.toast("Opening Calendar...");
      return;
    }

    const icsContent = generateICS([task]);
    downloadICSFile(icsContent, `${sanitizeFilename(task.title)}.ics`);
    Native.vibrate(40);
    Native.toast("Calendar file ready! Tap to import");
  }
};

// Theme Management
function initTheme() {
  const saved = Native.getData('app_theme') || localStorage.getItem('app_theme') || 'light';
  applyTheme(saved);

  // Listen for cross-window / hub postMessage
  window.addEventListener('message', (e) => {
    if (e.data && e.data.type === 'SET_THEME') {
      applyTheme(e.data.theme);
    }
  });

  window.addEventListener('storage', (e) => {
    if (e.key === 'app_theme' && e.newValue) {
      applyTheme(e.newValue);
    }
  });
}

function applyTheme(theme) {
  document.documentElement.setAttribute('data-theme', theme);
  document.body.classList.toggle('dark', theme === 'dark');
  Native.saveData('app_theme', theme);
  localStorage.setItem('app_theme', theme);
  updateThemeIcon(theme);
}

function toggleTheme() {
  const current = document.documentElement.getAttribute('data-theme') === 'dark' ? 'dark' : 'light';
  const next = current === 'dark' ? 'light' : 'dark';
  applyTheme(next);
  Native.vibrate(30);
  Native.toast(`Switched to ${next} mode`);
}

function updateThemeIcon(theme) {
  const icon = document.getElementById('themeIcon');
  if (!icon) return;
  if (theme === 'dark') {
    // Sun icon for dark mode (click to go light)
    icon.innerHTML = `<svg fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 3v1m0 16v1m9-9h-1M4 12H3m15.364 6.364l-.707-.707M6.343 6.343l-.707-.707m12.728 0l-.707.707M6.343 17.657l-.707.707M16 12a4 4 0 11-8 0 4 4 0 018 0z"/></svg>`;
  } else {
    // Moon icon for light mode (click to go dark)
    icon.innerHTML = `<svg fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M20.354 15.354A9 9 0 018.646 3.646 9.003 9.003 0 0012 21a9.003 9.003 0 008.354-5.646z"/></svg>`;
  }
}

// State
let tasks = [];
let currentFilter = 'all';
let currentPhotoBase64 = null;

document.addEventListener('DOMContentLoaded', () => {
  initTheme();
  loadTasks();
  setupEventListeners();
  renderTasks();
});

function loadTasks() {
  try {
    const saved = Native.getData('photo_scheduler_tasks');
    if (saved) {
      tasks = JSON.parse(saved);
    } else {
      const tomorrow = new Date();
      tomorrow.setDate(tomorrow.getDate() + 1);
      tomorrow.setHours(14, 0, 0, 0);

      tasks = [];
      saveTasks();
    }
  } catch (e) {
    tasks = [];
  }
}

function saveTasks() {
  Native.saveData('photo_scheduler_tasks', JSON.stringify(tasks));
}

function setupEventListeners() {
  const fileInput = document.getElementById('taskPhotoInput');
  fileInput.addEventListener('change', handlePhotoSelect);

  const form = document.getElementById('taskForm');
  form.addEventListener('submit', handleTaskSubmit);

  const search = document.getElementById('searchInput');
  search.addEventListener('input', () => renderTasks());

  document.querySelectorAll('.filter-chip').forEach(chip => {
    chip.addEventListener('click', (e) => {
      document.querySelectorAll('.filter-chip').forEach(c => c.classList.remove('active'));
      e.target.classList.add('active');
      currentFilter = e.target.dataset.filter;
      renderTasks();
    });
  });

  document.querySelectorAll('.preset-chip').forEach(chip => {
    chip.addEventListener('click', (e) => {
      const hours = parseInt(e.target.dataset.hours, 10);
      const targetDate = new Date(Date.now() + hours * 3600 * 1000);
      document.getElementById('taskDeadline').value = formatDateTimeLocal(targetDate);
    });
  });

  const modal = document.getElementById('imageModal');
  modal.addEventListener('click', () => modal.classList.remove('active'));
}

function handlePhotoSelect(e) {
  const file = e.target.files[0];
  if (!file) return;

  const reader = new FileReader();
  reader.onload = (event) => {
    const img = new Image();
    img.onload = () => {
      const maxDim = 800;
      let width = img.width;
      let height = img.height;
      if (width > maxDim || height > maxDim) {
        if (width > height) {
          height = Math.round((height * maxDim) / width);
          width = maxDim;
        } else {
          width = Math.round((width * maxDim) / height);
          height = maxDim;
        }
      }

      const canvas = document.createElement('canvas');
      canvas.width = width;
      canvas.height = height;
      const ctx = canvas.getContext('2d');
      ctx.drawImage(img, 0, 0, width, height);

      currentPhotoBase64 = canvas.toDataURL('image/jpeg', 0.75);

      const preview = document.getElementById('photoPreview');
      preview.src = currentPhotoBase64;
      preview.classList.add('has-image');
      document.getElementById('removePhotoBtn').style.display = 'inline-flex';
      Native.vibrate(30);
    };
    img.src = event.target.result;
  };
  reader.readAsDataURL(file);
}

function removeCurrentPhoto() {
  currentPhotoBase64 = null;
  const preview = document.getElementById('photoPreview');
  preview.src = '';
  preview.classList.remove('has-image');
  document.getElementById('taskPhotoInput').value = '';
  document.getElementById('removePhotoBtn').style.display = 'none';
}

function handleTaskSubmit(e) {
  e.preventDefault();
  const title = document.getElementById('taskTitle').value.trim();
  const deadline = document.getElementById('taskDeadline').value;
  const desc = document.getElementById('taskDesc').value.trim();
  const subtasksRaw = document.getElementById('taskSubtasks').value.trim();

  if (!title) {
    Native.toast("Title is required");
    return;
  }
  if (!deadline) {
    Native.toast("Please select a deadline");
    return;
  }

  const subtasks = subtasksRaw
    ? subtasksRaw.split('\n').map(s => s.trim()).filter(Boolean).map(text => ({ text, done: false }))
    : [];

  const newTask = {
    id: Date.now().toString(),
    title,
    deadline,
    description: desc,
    photo: currentPhotoBase64,
    done: false,
    subtasks,
    createdAt: Date.now()
  };

  tasks.unshift(newTask);
  saveTasks();
  renderTasks();

  e.target.reset();
  removeCurrentPhoto();
  toggleForm(false);
  Native.vibrate(40);
  Native.toast("Task created!");
}

function toggleForm(show) {
  const formCard = document.getElementById('taskFormCard');
  const toggleBtn = document.getElementById('toggleFormBtn');
  if (show === undefined) {
    formCard.style.display = formCard.style.display === 'none' ? 'block' : 'none';
  } else {
    formCard.style.display = show ? 'block' : 'none';
  }
  toggleBtn.textContent = formCard.style.display === 'none' ? '+ Add' : 'Close';
}

function toggleTaskDone(id) {
  const task = tasks.find(t => t.id === id);
  if (task) {
    task.done = !task.done;
    saveTasks();
    renderTasks();
    Native.vibrate(30);
  }
}

function toggleSubtaskDone(taskId, subtaskIdx) {
  const task = tasks.find(t => t.id === taskId);
  if (task && task.subtasks[subtaskIdx]) {
    task.subtasks[subtaskIdx].done = !task.subtasks[subtaskIdx].done;
    saveTasks();
    renderTasks();
    Native.vibrate(20);
  }
}

function deleteTask(id) {
  tasks = tasks.filter(t => t.id !== id);
  saveTasks();
  renderTasks();
  Native.vibrate(40);
  Native.toast("Task deleted");
}

function viewImage(src) {
  const modal = document.getElementById('imageModal');
  const modalImg = document.getElementById('modalImage');
  modalImg.src = src;
  modal.classList.add('active');
  Native.vibrate(30);
}

function renderTasks() {
  const container = document.getElementById('taskList');
  const query = document.getElementById('searchInput').value.toLowerCase().trim();
  const now = new Date().getTime();

  const filtered = tasks.filter(task => {
    const taskDate = new Date(task.deadline).getTime();
    const isOverdue = !task.done && taskDate < now;

    if (currentFilter === 'upcoming' && (task.done || isOverdue)) return false;
    if (currentFilter === 'overdue' && (task.done || !isOverdue)) return false;
    if (currentFilter === 'done' && !task.done) return false;

    if (query) {
      const matchTitle = task.title.toLowerCase().includes(query);
      const matchDesc = (task.description || '').toLowerCase().includes(query);
      if (!matchTitle && !matchDesc) return false;
    }
    return true;
  });

  if (filtered.length === 0) {
    container.innerHTML = `<div class="empty-state">No tasks found in this view.</div>`;
    return;
  }

  container.innerHTML = filtered.map(task => {
    const taskTime = new Date(task.deadline);
    const diffHours = (taskTime.getTime() - now) / (1000 * 3600);
    let badgeClass = 'upcoming';
    let badgeText = 'Upcoming';

    if (task.done) {
      badgeClass = 'done';
      badgeText = 'Done';
    } else if (diffHours < 0) {
      badgeClass = 'urgent';
      badgeText = 'Overdue';
    } else if (diffHours <= 24) {
      badgeClass = 'today';
      badgeText = 'Due Today';
    }

    const subtasksHtml = (task.subtasks && task.subtasks.length > 0)
      ? `<div class="task-subtasks">
          ${task.subtasks.map((st, idx) => `
            <label class="subtask-item">
              <input type="checkbox" class="subtask-checkbox" ${st.done ? 'checked' : ''} onchange="toggleSubtaskDone('${task.id}', ${idx})" />
              <span style="${st.done ? 'text-decoration:line-through;color:var(--text-muted)' : ''}">${escapeHtml(st.text)}</span>
            </label>
          `).join('')}
        </div>`
      : '';

    const photoHtml = task.photo
      ? `<img src="${task.photo}" class="task-thumb" alt="Task photo" onclick="viewImage('${task.photo}')" />`
      : `<div class="task-thumb-placeholder">
          <svg fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="1.5" d="M4 16l4.586-4.586a2 2 0 012.828 0L16 16m-2-2l1.586-1.586a2 2 0 012.828 0L20 14m-6-6h.01M6 20h12a2 2 0 002-2V6a2 2 0 00-2-2H6a2 2 0 00-2 2v12a2 2 0 002 2z"/></svg>
        </div>`;

    return `
      <div class="task-item ${task.done ? 'is-done' : ''}">
        ${photoHtml}
        <div class="task-content">
          <div class="task-header">
            <span class="task-title" title="${escapeHtml(task.title)}">${escapeHtml(task.title)}</span>
            <span class="status-badge ${badgeClass}">${badgeText}</span>
          </div>
          <div class="task-time">
            <svg style="width:12px;height:12px" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 8v4l3 3m6-3a9 9 0 11-18 0 9 9 0 0118 0z"/></svg>
            ${formatDisplayDate(taskTime)}
          </div>
          ${task.description ? `<div class="task-desc">${escapeHtml(task.description)}</div>` : ''}
          ${subtasksHtml}
          <div class="task-actions">
            <button class="btn btn-sm btn-outline" onclick="Native.addToCalendar(tasks.find(t => t.id === '${task.id}'))" title="Add to Calendar">
              <svg fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M8 7V3m8 4V3m-9 8h10M5 21h14a2 2 0 002-2V7a2 2 0 00-2-2H5a2 2 0 00-2 2v12a2 2 0 002 2z"/></svg>
              Cal
            </button>
            <button class="btn btn-sm ${task.done ? 'btn-outline' : 'btn-success'}" onclick="toggleTaskDone('${task.id}')">
              ${task.done ? 'Undo' : 'Complete'}
            </button>
            <button class="btn btn-sm btn-danger" onclick="deleteTask('${task.id}')">
              Del
            </button>
          </div>
        </div>
      </div>
    `;
  }).join('');
}

function formatDateTimeLocal(date) {
  const pad = n => String(n).padStart(2, '0');
  return `${date.getFullYear()}-${pad(date.getMonth() + 1)}-${pad(date.getDate())}T${pad(date.getHours())}:${pad(date.getMinutes())}`;
}

function formatDisplayDate(date) {
  return date.toLocaleString([], {
    month: 'short',
    day: 'numeric',
    hour: '2-digit',
    minute: '2-digit'
  });
}

function escapeHtml(str) {
  if (!str) return '';
  return str.replace(/[&<>'"]/g, tag => ({
    '&': '&amp;',
    '<': '&lt;',
    '>': '&gt;',
    "'": '&#39;',
    '"': '&quot;'
  }[tag] || tag));
}

function sanitizeFilename(str) {
  return (str || 'task').replace(/[^a-z0-9_-]/gi, '_').toLowerCase();
}

function generateICS(taskList) {
  const formatICSDate = (d) => {
    return new Date(d).toISOString().replace(/-|:|\.\d+/g, '');
  };

  let ics = [
    "BEGIN:VCALENDAR",
    "VERSION:2.0",
    "PRODID:-//FA//PhotoScheduler//EN",
    "CALSCALE:GREGORIAN",
    "METHOD:PUBLISH"
  ];

  taskList.forEach(t => {
    const start = formatICSDate(t.deadline);
    const end = formatICSDate(new Date(t.deadline).getTime() + 3600000);
    const desc = (t.description || '') + (t.subtasks?.length ? "\nTasks:\n" + t.subtasks.map(s => `- ${s.text}`).join('\n') : '');

    ics.push("BEGIN:VEVENT");
    ics.push(`UID:${t.id}@photoscheduler.fa`);
    ics.push(`DTSTAMP:${formatICSDate(new Date())}`);
    ics.push(`DTSTART:${start}`);
    ics.push(`DTEND:${end}`);
    ics.push(`SUMMARY:${t.title.replace(/\n/g, ' ')}`);
    ics.push(`DESCRIPTION:${desc.replace(/\n/g, '\\n')}`);
    ics.push("STATUS:CONFIRMED");
    ics.push("END:VEVENT");
  });

  ics.push("END:VCALENDAR");
  return ics.join("\r\n");
}

function downloadICSFile(content, filename) {
  const blob = new Blob([content], { type: 'text/calendar;charset=utf-8' });
  const link = document.createElement('a');
  link.href = URL.createObjectURL(blob);
  link.setAttribute('download', filename);
  document.body.appendChild(link);
  link.click();
  document.body.removeChild(link);
}

function exportAllICS() {
  if (!tasks.length) {
    Native.toast("No tasks to export");
    return;
  }
  const ics = generateICS(tasks);
  downloadICSFile(ics, `all_tasks_${new Date().toISOString().slice(0, 10)}.ics`);
  Native.toast("Exported all tasks to Calendar file");
  Native.vibrate(40);
}
