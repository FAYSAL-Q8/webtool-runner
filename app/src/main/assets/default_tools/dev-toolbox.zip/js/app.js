/**
 * Author: Faysal Alibrahim
 * GitHub: https://github.com/FAYSAL-Q8
 */
const Native = {
  toast: (msg) => {
    if (window.AndroidBridge?.showToast) window.AndroidBridge.showToast(msg);
    else console.log("[Toast]", msg);
  },
  copy: async (text) => {
    if (window.AndroidBridge?.copyToClipboard) {
      window.AndroidBridge.copyToClipboard(text);
    } else {
      await navigator.clipboard.writeText(text);
    }
    Native.toast("Copied to clipboard!");
  },
  vibrate: (ms = 50) => {
    if (window.AndroidBridge?.vibrate) window.AndroidBridge.vibrate(ms);
    else if (navigator.vibrate) navigator.vibrate(ms);
  },
  share: (title, text) => {
    if (window.AndroidBridge?.shareText) window.AndroidBridge.shareText(title, text);
    else if (navigator.share) navigator.share({ title, text });
    else Native.copy(text);
  },
  saveData: (key, value) => {
    if (window.AndroidBridge?.saveData) window.AndroidBridge.saveData(key, value);
    else localStorage.setItem(key, value);
  },
  getData: (key) => {
    if (window.AndroidBridge?.getData) return window.AndroidBridge.getData(key);
    return localStorage.getItem(key);
  }
};

// Theme Management
function initTheme() {
  const saved = Native.getData('app_theme') || localStorage.getItem('app_theme') || 'light';
  applyTheme(saved);

  window.addEventListener('message', (e) => {
    if (e.data && e.data.type === 'SET_THEME') {
      applyTheme(e.data.theme);
    }
  });

  window.addEventListener('storage', (e) => {
    if (e.key === 'app_theme' && e.newValue) {
      applyTheme(e.newValue);
    }
  });
}

function applyTheme(theme) {
  document.documentElement.setAttribute('data-theme', theme);
  document.body.classList.toggle('dark', theme === 'dark');
  Native.saveData('app_theme', theme);
  localStorage.setItem('app_theme', theme);
  updateThemeIcon(theme);
}

function toggleTheme() {
  const current = document.documentElement.getAttribute('data-theme') === 'dark' ? 'dark' : 'light';
  const next = current === 'dark' ? 'light' : 'dark';
  applyTheme(next);
  Native.vibrate(30);
  Native.toast(`Switched to ${next} mode`);
}

function updateThemeIcon(theme) {
  const icon = document.getElementById('themeIcon');
  if (!icon) return;
  if (theme === 'dark') {
    icon.innerHTML = `<svg fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 3v1m0 16v1m9-9h-1M4 12H3m15.364 6.364l-.707-.707M6.343 6.343l-.707-.707m12.728 0l-.707.707M6.343 17.657l-.707.707M16 12a4 4 0 11-8 0 4 4 0 018 0z"/></svg>`;
  } else {
    icon.innerHTML = `<svg fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M20.354 15.354A9 9 0 018.646 3.646 9.003 9.003 0 0012 21a9.003 9.003 0 008.354-5.646z"/></svg>`;
  }
}

let currentTab = 'json';

document.addEventListener('DOMContentLoaded', () => {
  initTheme();
  setupTabs();
  setupLiveCounters();
  loadSavedText();
});

function setupTabs() {
  document.querySelectorAll('.nav-tab').forEach(tab => {
    tab.addEventListener('click', (e) => {
      document.querySelectorAll('.nav-tab').forEach(t => t.classList.remove('active'));
      e.target.classList.add('active');
      currentTab = e.target.dataset.tab;

      document.querySelectorAll('.tool-panel').forEach(p => p.style.display = 'none');
      document.getElementById(`panel-${currentTab}`).style.display = 'flex';
      Native.vibrate(20);
    });
  });
}

function loadSavedText() {
  const saved = Native.getData('dev_toolbox_last_input');
  if (saved) {
    document.getElementById('jsonInput').value = saved;
    updateJsonStats();
  }
}

function saveCurrentInput(val) {
  Native.saveData('dev_toolbox_last_input', val);
}

// =================== JSON TOOLS ===================
function formatJson(spaces = 2) {
  const el = document.getElementById('jsonInput');
  const val = el.value.trim();
  if (!val) return;

  try {
    const parsed = JSON.parse(val);
    el.value = JSON.stringify(parsed, null, spaces);
    setJsonStatus("Valid JSON", true);
    saveCurrentInput(el.value);
    Native.vibrate(30);
    Native.toast("Formatted");
  } catch (err) {
    setJsonStatus(err.message, false);
    Native.vibrate(50);
  }
  updateJsonStats();
}

function minifyJson() {
  const el = document.getElementById('jsonInput');
  const val = el.value.trim();
  if (!val) return;

  try {
    const parsed = JSON.parse(val);
    el.value = JSON.stringify(parsed);
    setJsonStatus("Minified", true);
    saveCurrentInput(el.value);
    Native.vibrate(30);
    Native.toast("Minified");
  } catch (err) {
    setJsonStatus(err.message, false);
    Native.vibrate(50);
  }
  updateJsonStats();
}

function validateJson() {
  const val = document.getElementById('jsonInput').value.trim();
  if (!val) {
    setJsonStatus("Empty", false);
    return;
  }
  try {
    JSON.parse(val);
    setJsonStatus("Valid JSON", true);
    Native.toast("Valid JSON");
    Native.vibrate(30);
  } catch (err) {
    setJsonStatus(err.message, false);
    Native.vibrate(60);
  }
}

function clearJson() {
  document.getElementById('jsonInput').value = '';
  setJsonStatus("", true);
  updateJsonStats();
  saveCurrentInput('');
}

function setJsonStatus(msg, isValid) {
  const badge = document.getElementById('jsonStatusBadge');
  if (!msg) {
    badge.style.display = 'none';
    return;
  }
  badge.style.display = 'inline-block';
  badge.textContent = msg;
  badge.className = `status-badge ${isValid ? 'status-valid' : 'status-error'}`;
}

function updateJsonStats() {
  const val = document.getElementById('jsonInput').value;
  const chars = val.length;
  const lines = val ? val.split('\n').length : 0;
  const bytes = new Blob([val]).size;
  document.getElementById('jsonStats').textContent = `${chars} chars • ${lines} lines • ${bytes} B`;
}

// =================== BASE64 & URL ===================
function processBase64(mode) {
  const inputEl = document.getElementById('codecInput');
  const outputEl = document.getElementById('codecOutput');
  const val = inputEl.value;

  if (!val) return;

  try {
    if (mode === 'encode') {
      outputEl.value = btoa(unescape(encodeURIComponent(val)));
      Native.toast("Base64 Encoded");
    } else {
      outputEl.value = decodeURIComponent(escape(atob(val.trim())));
      Native.toast("Base64 Decoded");
    }
    Native.vibrate(30);
  } catch (err) {
    Native.toast("Invalid Base64 input");
    Native.vibrate(50);
  }
}

function processUrl(mode) {
  const inputEl = document.getElementById('codecInput');
  const outputEl = document.getElementById('codecOutput');
  const val = inputEl.value;

  if (!val) return;

  try {
    if (mode === 'encode') {
      outputEl.value = encodeURIComponent(val);
      Native.toast("URL Encoded");
    } else {
      outputEl.value = decodeURIComponent(val);
      Native.toast("URL Decoded");
    }
    Native.vibrate(30);
  } catch (err) {
    Native.toast("Malformed URL string");
    Native.vibrate(50);
  }
}

function copyOutput(id) {
  const text = document.getElementById(id).value;
  if (text) {
    Native.copy(text);
  }
}

function shareOutput(id) {
  const text = document.getElementById(id).value;
  if (text) {
    Native.share("DevToolbox Output", text);
  }
}

// =================== GENERATORS & TIME ===================
function generateUuid(count = 1) {
  const list = [];
  for (let i = 0; i < count; i++) {
    list.push(crypto.randomUUID ? crypto.randomUUID() : fakeUuid());
  }
  const result = list.join('\n');
  document.getElementById('genOutput').value = result;
  Native.toast(`Generated ${count} UUID${count > 1 ? 's' : ''}`);
  Native.vibrate(30);
}

function fakeUuid() {
  return 'xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx'.replace(/[xy]/g, function(c) {
    const r = Math.random() * 16 | 0, v = c === 'x' ? r : (r & 0x3 | 0x8);
    return v.toString(16);
  });
}

function epochToDate() {
  const raw = document.getElementById('epochInput').value.trim();
  if (!raw) return;

  let ms = parseInt(raw, 10);
  if (raw.length <= 10) ms *= 1000;

  const date = new Date(ms);
  if (isNaN(date.getTime())) {
    Native.toast("Invalid Epoch");
    return;
  }
  document.getElementById('genOutput').value = `ISO: ${date.toISOString()}\nLocal: ${date.toLocaleString()}`;
  Native.vibrate(30);
}

function nowToEpoch() {
  const now = Date.now();
  document.getElementById('epochInput').value = Math.floor(now / 1000);
  document.getElementById('genOutput').value = `Sec: ${Math.floor(now / 1000)}\nMS: ${now}\nISO: ${new Date(now).toISOString()}`;
  Native.vibrate(30);
}

// =================== TEXT INSPECTOR ===================
function setupLiveCounters() {
  const textInput = document.getElementById('textInspectorInput');
  textInput.addEventListener('input', updateTextStats);

  const jsonInput = document.getElementById('jsonInput');
  jsonInput.addEventListener('input', () => {
    updateJsonStats();
    saveCurrentInput(jsonInput.value);
  });
}

function updateTextStats() {
  const text = document.getElementById('textInspectorInput').value;
  const chars = text.length;
  const words = text.trim() ? text.trim().split(/\s+/).length : 0;
  const lines = text ? text.split('\n').length : 0;
  const bytes = new Blob([text]).size;

  document.getElementById('statWords').textContent = words;
  document.getElementById('statChars').textContent = chars;
  document.getElementById('statLines').textContent = lines;
  document.getElementById('statBytes').textContent = bytes;
}

function transformCase(mode) {
  const el = document.getElementById('textInspectorInput');
  const val = el.value;
  if (!val) return;

  if (mode === 'upper') {
    el.value = val.toUpperCase();
  } else if (mode === 'lower') {
    el.value = val.toLowerCase();
  } else if (mode === 'title') {
    el.value = val.replace(/\w\S*/g, (txt) => txt.charAt(0).toUpperCase() + txt.substr(1).toLowerCase());
  } else if (mode === 'camel') {
    el.value = val.replace(/(?:^\w|[A-Z]|\b\w|\s+)/g, (match, index) => {
      if (+match === 0) return "";
      return index === 0 ? match.toLowerCase() : match.toUpperCase();
    });
  } else if (mode === 'kebab') {
    el.value = val.match(/[A-Z]{2,}(?=[A-Z][a-z]+[0-9]*|\b)|[A-Z]?[a-z]+[0-9]*|[A-Z]|[0-9]+/g)
      ?.map(x => x.toLowerCase())
      .join('-') || val;
  }

  updateTextStats();
  Native.vibrate(30);
  Native.toast("Transformed");
}
